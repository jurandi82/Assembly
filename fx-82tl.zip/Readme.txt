		        ***CASIOFX***
				  
		     *Functions for CASIO fx-82TL ex-users *

	| d/c | a b/c | MODE | ENG | --> | UTEIS |

"d/c" turn 1.5 to 3/2
"a b/c" turn 1.5 to 1+1/2
"MODE" Change RPN/Algebric mode
"ENG" Turn 1000 to 1*10^3
"-->" Turn 0.001 to 1*10^0

"UTEIS" SubMenu

	|PROOT|DIVIS|

"PROOT" polynal's roots , for 'X^2 -2*x + 1' usage '[1 -2 1]'
"DIVIS" divisors, eg. 'x^2' result is {1 x x^2}


Jurandi Almeida Fran�a
<hpmam@minaro.cjb.net>
http://minaro.cjb.net

PS: Meu ingl�s n�o � dos melhores, mas acho da j� d� pra gringo entender...